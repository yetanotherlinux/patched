#!/bin/sh

exec ./test-ftell${EXEEXT} 1 2 < "$srcdir/test-ftell2.sh"
